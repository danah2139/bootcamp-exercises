for (let i = 1; i < 51; i++) {
	console.log(`Voter number ${i} is currently voting`);
}
