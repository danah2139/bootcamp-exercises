import React from 'react';
const Q1Input = () => {
	return <input type="range" min="0" max="10" />;
};

export default Q1Input;
