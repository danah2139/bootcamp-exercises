import React from 'react';

const Q1Title = () => {
	const title = 'How Much You Love Front End?';
	return (
		<div>
			<h3>{title}</h3>
		</div>
	);
};
export default Q1Title;
