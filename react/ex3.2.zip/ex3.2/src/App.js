import './App.css';
import Quiz from './Quiz';

function App() {
	return <Quiz />;
}

export default App;
