import React from 'react';

const QuizTitle = () => {
	const title = 'How Do You Like Front End?';

	return (
		<div>
			<h2>{title}</h2>
		</div>
	);
};
export default QuizTitle;
