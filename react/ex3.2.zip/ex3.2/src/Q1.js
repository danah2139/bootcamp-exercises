import Q1Title from './Q1Title';
import Q1Input from './Q1Input';
import React from 'react';

const Q1 = () => {
	return (
		<div style={{ padding: '10px 0' }}>
			<Q1Title />
			<Q1Input />
		</div>
	);
};
export default Q1;
