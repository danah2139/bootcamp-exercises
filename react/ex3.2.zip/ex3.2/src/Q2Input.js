import React from 'react';

const Q2Input = () => {
	return (
		<div>
			<input></input>
		</div>
	);
};
export default Q2Input;
