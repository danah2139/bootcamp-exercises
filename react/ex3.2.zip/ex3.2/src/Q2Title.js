import React from 'react';

const Q2Title = () => {
	const title = 'What is your favourite front end feature topic?';
	return (
		<div>
			<h3>{title}</h3>
		</div>
	);
};
export default Q2Title;
