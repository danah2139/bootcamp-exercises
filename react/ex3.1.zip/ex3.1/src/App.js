import './App.css';

function App() {
	return (
		<div className="box green">
			<div className="box blue">
				<div className="box pink">
					<div className="box purple"></div>
					<div className="box purple"></div>
				</div>
			</div>
		</div>
	);
}

export default App;
